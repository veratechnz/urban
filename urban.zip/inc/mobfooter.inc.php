<!-- Mobile Footer --> 
  <div class="row visible-xs" id="nomarg">
    <div class="col-md-12">
    	 <div class="urban-div vboffset1 center-block">
            <img src="images/urban-div-mob.png" alt="" class="center-block img-responsive vboffset1">
         </div>
        </div>
         </div>
         <div class="row" id="nomarg">
         	<div class="col">
         	<div class="footmob gray visible-xs">
          		<p class="text-center gray"><span class="foota">
          			<a href="tel:03-477-2277"><i class="fa fa-phone fa-2x footyspanb"></i></a>
          			<a href="mailto:faye@urbancalm.co.nz"><i class="fa fa-envelope fa-2x footyspanb"></i></a>
          			<a href="https://www.facebook.com/pages/Urban-Calm-Yin-Yoga-Centre/201863603334816" target="_blank"><i class="fa fa-facebook-square fa-2x footyspanb"></i></a></p>
    		</div>
         </div>
       </div>     
  </div>
</div>
<!-- Mobile Footer End -->