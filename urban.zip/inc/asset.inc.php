    <div class="container-fluid">
      <div class="row">
          <div class="col-md-12">
            <img src="images/pagedevider900.png" class="center-block">
            <p class="text-center asset">Phone: 03-477-2277 | Level 1, Clarion Building, 286 Princes Street, Dunedin</p>
          </div>
      </div>
    </div>