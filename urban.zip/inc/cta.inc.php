            <div class="col-sm-12">     
                        <!-- Blockquote -->
                        <div class="col-md-12 vboffset">
                          <hr>
                        <blockquote>
                        <h2>"YIN IS THE MOST RELAXING YOGA I'VE EVER DONE YET. I FEEL STRONGER AND MORE SUPPLE THAN EVER. 
                            ITS ALSO IS AS MUCH MIND TIME AND BODY TIME - A QUIET OASIS TO REGROUP AND RECHARGE FOR THE WEEK."</h2>
                            <h2 class="person">LIZ</h2>
                            <!-- Float Fix div -->
                            <div style="clear: both;"></div>
                            <!-- Float Fix div ends -->
                        </blockquote>
                        <hr>
                        </div>
                        <!-- Blockquote End -->
            </div>
            <!-- Booking Info Ends -->
            <!-- CTA Buttons -->
            <div class="col-md-4 vboffset1">
              <h3 class="text-center">TEACHER TRAINING</h3>
                <a href="bookings.php" class="btn btn-default btn-lg center-block bwidth voffset1">BOOK TODAY</a>                  
            </div>
            <div class="col-md-4 vboffset1">
              <h3 class="text-center">PAYMENTS ONLINE</h3>
                <a href="bookings.php" class="btn btn-default btn-lg center-block bwidth voffset1">BOOK TODAY</a>                  
            </div>
            <div class="col-md-4 vboffset1">
              <h3 class="text-center">BOOK YOUR CLASS</h3>
                <a href="bookings.php" class="btn btn-default btn-lg center-block bwidth voffset1">BOOK TODAY</a>                  
            </div>
            <!-- CTA Buttons End -->
