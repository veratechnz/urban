  <!-- Desktop Footer -->
  <div class="container-fluid hidden-xs" id="footer">
    	<div class="container">
      <div class="row">
          <div class="col-md-6">
          <p><a target="_blank" href="https://goo.gl/maps/Q4jKQ"><img src="images/map.jpg" title="Click To Launch Our Google Map" alt="Click To Launch Our Google Map" class="img-responsive center-block footmap" href="https://goo.gl/maps/Q4jKQ"></a></p>
          </div>
          <div class="col-md-6">
            <h3 class="footyhead">CONTACT
              <span class="footyiconsb">
                <a href="#"><i class="fa fa-twitter-square foots"></i></a>
                <a href="#"><i class="fa fa-google-plus-square foots"></i></a>
                <a href="#"><i class="fa fa-linkedin-square foots"></i></a>
                <a href="https://www.facebook.com/pages/Urban-Calm-Yin-Yoga-Centre/201863603334816" target="_blank"><i class="fa fa-facebook-square foots"></i></a>
                </span>
            </h3>
          	<p class="footy"><i class="fa fa-phone footicon"></i><span class="footyspan">+64 03 477 0277</span></p>
          	<p class="footy"><i class="fa fa-envelope-o footicon"></i><span class="footyspan">faye@urbanclam.co.nz</span></p>
          	<p class="footy"><i class="fa fa-map-marker footicon"></i><span class="footyspan">Level 1 Clarion building 286<br>
          		<span class="footyspanb">Princes Street Dunedin</span></p>
			   </div>
        </div>
      </div>
  </div>
<!-- Desktop Footer End  -->



