<div class="row vboffset1 hidden-xs">
	<div class="col-md-12">
          <!-- Urban Image Div -->
          <div class="urban-div">
            <img src="images/urban-div.png" alt="" class="center-block img-responsive">
          </div>
          <p class="text-center voffset1 nusize">PH: 03 477 2277 | Level 1, Clarion Building, 286 Princess Street Dunedin</p>
          <!-- Urban Image Div -->
	</div>
</div>