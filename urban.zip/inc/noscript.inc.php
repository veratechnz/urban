    <noscript>
      <style>body{display: block;}</style>
    </noscript>